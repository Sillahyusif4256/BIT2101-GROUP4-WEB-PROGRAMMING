<?php
// 1. Start the session and connect to the database
session_start();
include 'db_connect.php';

// 2. SECURITY: If the user is not logged in, send them back to the login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 3. DATABASE LOGIC: Fetch all users from the database
$query = "SELECT id, username, email, role FROM users ORDER BY id DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangs FC | Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <div class="dashboard-wrapper">
        
        <aside class="sidebar">
            <div class="logo-area">Bangs FC Admin</div>
            <nav class="dashboard-nav">
                <ul>
                    <li class="nav-item active"><a href="dashboard.php"><i class="fas fa-users"></i> User Management</a></li>
                    <li class="nav-item"><a href="About.html"><i class="fas fa-envelope"></i> About Us</a></li>
                    <li class="nav-item"><a href="index.html"><i class="fas fa-home"></i> View Website</a></li>
                    <li class="nav-item"><a href="login.html"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <header class="content-header">
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
                <div class="user-stats">
                    <span>Total Users: <?php echo $result->num_rows; ?></span>
                </div>
            </header>

            <section class="user-table-section">
                <h2>Registered Users</h2>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // 4. LOOP: Check if there are users and display them
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row['id'] . "</td>";
                                    echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                    echo "<td><span class='role-tag'>" . $row['role'] . "</span></td>";
                                    echo "<td>
                                            <a href='edit_user.php?id=".$row['id']."' class='btn-action edit'><i class='fas fa-edit'></i></a>
                                            <a href='delete_user.php?id=".$row['id']."' class='btn-action delete' onclick='return confirm(\"Are you sure?\")'><i class='fas fa-trash'></i></a>
                                          </td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5'>No users found.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>

</body>
</html>