<?php 
include 'db_connect.php'; 
// Query to get all users
$user_list = $conn->query("SELECT id, username, email, role FROM users");
?>
<tbody>
    <?php while($user = $user_list->fetch_assoc()): ?>
    <tr>
        <td><?php echo $user['id']; ?></td>
        <td><?php echo $user['username']; ?></td>
        <td><?php echo $user['email']; ?></td>
        <td><?php echo $user['role']; ?></td>
    </tr>
    <?php endwhile; ?>
</tbody>