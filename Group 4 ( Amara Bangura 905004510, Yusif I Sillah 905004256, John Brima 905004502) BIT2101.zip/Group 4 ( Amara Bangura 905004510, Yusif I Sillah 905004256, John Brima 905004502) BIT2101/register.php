<?php
// Start a session to use later for login messages
session_start();

// Include your database connection script
include 'db_connect.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 1. Sanitize and retrieve data
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password']; // Get the raw password

    // 2. HASH THE PASSWORD for SECURITY
    // PASSWORD_DEFAULT is the modern, strong hashing algorithm (recommended)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // 3. SQL Query to insert user
    $sql = "INSERT INTO users (username, email, password) 
            VALUES ('$username', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        // Success: Redirect to the login page
        $_SESSION['message'] = "Registration successful! Please log in.";
        header("Location: login.html");
        exit();
    } else {
        // Check for duplicate entry error (e.g., username or email already exists)
        if ($conn->errno == 1062) {
            $_SESSION['error'] = "Error: Username or Email already exists.";
        } else {
            $_SESSION['error'] = "Error: " . $conn->error;
        }
        header("Location: signup.html"); // Go back to signup page with error
        exit();
    }
} else {
    // If accessed directly
    header("Location: signup.html");
    exit();
}
$conn->close();
?>