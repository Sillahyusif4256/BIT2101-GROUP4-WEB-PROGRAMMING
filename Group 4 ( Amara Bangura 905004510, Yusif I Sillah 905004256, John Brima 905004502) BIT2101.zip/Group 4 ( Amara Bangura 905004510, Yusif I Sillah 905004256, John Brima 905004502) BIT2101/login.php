<?php
session_start();
require_once "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (empty($_POST["login"]) || empty($_POST["password"])) {
        $_SESSION["error"] = "All fields are required.";
        header("Location: login.html");
        exit();
    }

    $login = trim($_POST["login"]);
    $password = $_POST["password"];

    // Find user by username OR email
    $stmt = $conn->prepare(
        "SELECT id, username, password FROM users WHERE username = ? OR email = ? LIMIT 1"
    );
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];

            header("Location: dashboard.php");
            exit();
        }
    }

    // Login failed
    $_SESSION["error"] = "Invalid login details.";
    header("Location: login.html");
    exit();
}

// Block direct access
header("Location: login.html");
exit();
