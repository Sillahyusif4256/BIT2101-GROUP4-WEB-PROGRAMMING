<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $subject = isset($_POST['subject']) ? $conn->real_escape_string($_POST['subject']) : "Quick Request";
    $msg = $conn->real_escape_string($_POST['message']);

    $sql = "INSERT INTO messages (sender_name, sender_email, subject, message_body) 
            VALUES ('$name', '$email', '$subject', '$msg')";

    if ($conn->query($sql)) {
        echo "<script>alert('Message Sent!'); window.location.href='index.php';</script>";
    }
}
?>