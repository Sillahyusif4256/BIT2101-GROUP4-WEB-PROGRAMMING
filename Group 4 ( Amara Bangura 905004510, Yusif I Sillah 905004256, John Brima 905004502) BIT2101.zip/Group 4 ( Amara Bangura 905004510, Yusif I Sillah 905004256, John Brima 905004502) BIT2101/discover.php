<?php include 'db_connect.php'; ?>
<div class="discover-grid">
    <?php
    $result = $conn->query("SELECT * FROM players");
    while($row = $result->fetch_assoc()) {
        echo '
        <div class="player-card">
            <div class="player-image"><img src="'.$row['image_path'].'"></div>
            <div class="player-info">
                <h3>'.$row['full_name'].'</h3>
                <p>'.$row['position'].'</p>
                <a href="#" class="btn-view-profile">View Profile</a>
            </div>
        </div>';
    }
    ?>
</div>