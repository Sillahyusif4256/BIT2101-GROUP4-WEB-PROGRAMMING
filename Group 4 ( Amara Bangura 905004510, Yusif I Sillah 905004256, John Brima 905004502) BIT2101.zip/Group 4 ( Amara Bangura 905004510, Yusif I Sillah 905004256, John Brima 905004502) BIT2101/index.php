<?php
// Include the connection script
include 'db_connect.php';

// Now you can use the $conn variable to run database queries
$sql = "SELECT * FROM players"; // Example query
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Player Name: " . $row["name"]. " - Position: " . $row["position"]. "<br>";
    }
} else {
    echo "0 results";
}

// Close the connection when done
$conn->close();
?>