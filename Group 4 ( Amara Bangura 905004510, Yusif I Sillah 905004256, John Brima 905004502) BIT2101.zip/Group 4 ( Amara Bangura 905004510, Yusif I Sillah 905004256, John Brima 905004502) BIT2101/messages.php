<?php
session_start();
include 'db_connect.php';

// 1. Security check: Only logged-in users can see messages
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inbox - Bangs FC Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <div class="logo-area">Bangs FC Admin</div>
            <nav class="dashboard-nav">
                <ul>
                    <li class="nav-item"><a href="dashboard.php"><i class="fas fa-users"></i> User Management</a></li>
                    <li class="nav-item active"><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li class="nav-item"><a href="index.php"><i class="fas fa-home"></i> View Website</a></li>
                    <li class="nav-item"><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <header class="content-header">
                <div>
                    <h1>Inbox / Requests</h1>
                    <p>Total Messages: <strong><?php echo $result->num_rows; ?></strong></p>
                </div>
            </header>

            <section class="messages-section">
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <div class="message-card">
                            <div class="message-header">
                                <strong><i class="fas fa-user"></i> <?php echo htmlspecialchars($row['sender_name']); ?></strong> 
                                <span class="message-date"><?php echo date('M d, Y - H:i', strtotime($row['submitted_at'])); ?></span>
                            </div>
                            <div class="message-meta">
                                <small><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($row['sender_email']); ?></small>
                                <br>
                                <small><i class="fas fa-info-circle"></i> Subject: <?php echo htmlspecialchars($row['subject']); ?></small>
                            </div>
                            <div class="message-body">
                                <p><?php echo nl2br(htmlspecialchars($row['message_body'])); ?></p>
                            </div>
                            <div class="message-actions">
                                <a href="mailto:<?php echo $row['sender_email']; ?>" class="btn-reply">
                                    <i class="fas fa-reply"></i> Reply via Email
                                </a>
                                <a href="delete_msg.php?id=<?php echo $row['id']; ?>" 
                                   class="btn-delete-msg" 
                                   onclick="return confirm('Are you sure you want to delete this message?')">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="no-messages">
                        <i class="fas fa-folder-open" style="font-size: 3rem; color: #ccc;"></i>
                        <p>Your inbox is currently empty.</p>
                    </div>
                <?php endif; ?>
            </section>
        </main>
    </div>

</body>
</html>